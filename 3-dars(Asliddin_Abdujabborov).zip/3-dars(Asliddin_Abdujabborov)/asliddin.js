// Asliddin_Abdujabborov
// 3 - task

alert(`Chet elga ketamiz.`);

const uzs = prompt(`Alish qancha puling bor?`);

const xarajat1 = 500 * 9433.34;
const xarajat2 = 250 * 9433.34;
const xarajat3 = 120 * 10354.03;

const ketish_narxi = xarajat1 + xarajat2 + xarajat3;

if (uzs >= ketish_narxi) {
	console.log(`Oq yo'l, Alisher! Naqd ${ketish_narxi} so'mga tushyabsan lekin.`);
} else {
	console.log(`Alisher, ozgina sabr qilish kerak bo'lar ekan. Xarajat ${ketish_narxi} so'm bo'lib ketdi.`)
}





















